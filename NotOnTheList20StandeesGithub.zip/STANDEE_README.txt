20 separate transparent standees in public/assets/standees/. Existing game code must be updated to use standee assets.
